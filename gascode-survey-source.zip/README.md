# Gascode market research survey

Responsive web survey based on the Optimized Market Research Questionnaire, with Gascode's supplied blue-and-white logo. Household and property-manager tracks preserve Q1–Q7 and B1–B7. B6 is implemented as one preferred model; its printed table assigned a different preference label to each model, which does not form an unambiguous ranking question.

## Respondents
Open the published survey link on a phone or computer. Required questions are validated, optional business contact details require follow-up permission, and submission is confirmed only after durable database storage. Refreshing clears unsent answers. A retry uses the same response ID to avoid duplicates.

## Owner and analysis
Visit `/admin` and sign in with the owner's ChatGPT account. The server compares the authenticated email to the secret ADMIN_EMAIL. Download CSV or JSON, then upload the file to the private repository:
https://github.com/Tounayo/gascode-survey-responses

GitHub upload is a manual snapshot, not automatic synchronization. The public `Tounayo/gascode-survey` repository contains application code only. Never upload respondent exports to it. New private repositories may need to be added to the GitHub connector's repository permissions before Codex can analyze them.

## Data and questionnaire choices
- Every response includes ID, UTC timestamp, track, consent version, follow-up permission and answers keyed by question.
- Household fields: city, area, role, income, fuel, sizes, spend, refill, pain_running_out, pain_safety, pain_transport, pain_quality, appeal, connection_fee, switch.
- Property fields: city, area, role, company, sector, operating_city, units, setup, concerns, scope, model, timeline, authority, contact_name, contact_details.
- Added `Prefer not to say` for income; `Not applicable` for pain ratings and refill; and `Other / Less often` for refill. Cylinder size appears only for LPG users.
- Optional contact details are collected only on the property track, as in the source document.
- CSV exports protect against spreadsheet formula injection. JSON preserves literal values and arrays.
- Responses reside in a private D1 database. Exports require owner authentication. No response-list endpoint is public.

## Development
Requires Node 22.13+ and npm. Run `npm run install:ci`, `npm run db:generate` for schema changes, and `npm run dev`. Use the documented Sites publishing flow. The production worker lives in `dist/server/index.js`; assets in `dist/client`; migrations in `drizzle`.

`ADMIN_EMAIL` must be configured in hosted runtime secrets. Local `.env` is ignored and must never be committed. Apply generated migrations to the local database before local submission tests.

## Validation
TypeScript checks, production build, household and property submission/retry tests, required-field rejection, cross-origin rejection and anonymous export denial. Local test records do not migrate into production. WebMCP read-step tool validated with valid and invalid input.
