import {database} from "@/db";
import {isAdmin} from "@/lib/admin";
import {screening,income,usage,pains,adoption,profile,infrastructure,commercial,contact} from "@/lib/questionnaire";
export async function GET(request:Request){if(!await isAdmin())return Response.json({error:"Owner access required."},{status:403,headers:{"Cache-Control":"no-store"}});
 try{const rows=(await database().prepare("SELECT id,created_at,track,answers,consent_version,follow_up FROM responses ORDER BY created_at,id").all()).results;
 const records=rows.map(r=>{const {answers,...rest}=r;return {...rest,...JSON.parse(String(answers))}});
 const format=new URL(request.url).searchParams.get("format");const headers={"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Content-Disposition":`attachment; filename="gascode-responses-${new Date().toISOString().slice(0,10)}.${format==="csv"?"csv":"json"}"`};
 if(format!=="csv")return Response.json({schema_version:"2026-09-v1",exported_at:new Date().toISOString(),count:records.length,responses:records},{headers});
 const cols=["id","created_at","track","consent_version","follow_up",...new Set([...screening,income,...usage,...pains,...adoption,...profile,...infrastructure,...commercial,...contact].map(q=>q.id))];
 const cell=(v:unknown)=>{let s=Array.isArray(v)?v.join("; "):String(v??"");if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'};
 return new Response("\uFEFF"+[cols.map(cell).join(","),...records.map(r=>cols.map(c=>cell(r[c])).join(","))].join("\r\n"),{headers:{...headers,"Content-Type":"text/csv; charset=utf-8"}})
 }catch{return Response.json({error:"Results are temporarily unavailable. Please try again."},{status:503})}}
