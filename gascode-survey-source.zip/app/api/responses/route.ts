import {database} from "@/db";
import {cleanAnswers,validateAnswers,isBusiness, type Answers} from "@/lib/questionnaire";
export async function POST(request:Request){
 if(request.headers.get("origin")!==new URL(request.url).origin)return Response.json({error:"Please submit from the survey page."},{status:403});
 if(!request.headers.get("content-type")?.includes("application/json"))return Response.json({error:"Invalid format."},{status:415});
 const text=await request.text();if(text.length>16000)return Response.json({error:"Response is too large."},{status:413});
 let body;try{body=JSON.parse(text)}catch{return Response.json({error:"Invalid response."},{status:400})}
 if(!body||typeof body!=="object"||!body.answers||Array.isArray(body.answers)||typeof body.answers!=="object"||!/^([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})$/i.test(body.id)||body.consent!==true||typeof body.followUp!=="boolean"||body.website)return Response.json({error:"Please check the survey and consent before submitting."},{status:400});
 const errors=validateAnswers(body.answers as Answers);if(Object.keys(errors).length)return Response.json({error:"Please complete all required questions.",fields:errors},{status:400});
 const answers=cleanAnswers(body.answers);if((answers.contact_name||answers.contact_details)&&!body.followUp)return Response.json({error:"Please allow follow-up or remove your contact details."},{status:400});
 try{const db=database();await db.prepare("INSERT INTO responses (id,created_at,track,answers,consent_version,follow_up) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING").bind(body.id,new Date().toISOString(),isBusiness(answers)?"property":"household",JSON.stringify(answers),"2026-09-v1",body.followUp?1:0).run();return Response.json({id:body.id,saved:true},{status:201,headers:{"Cache-Control":"no-store"}})}catch(error){console.error("Survey storage unavailable",error instanceof Error?error.message:"unknown");return Response.json({error:"We could not save your response. Your answers are still here. Please try again."},{status:503})}
}
