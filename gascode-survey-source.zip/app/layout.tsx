import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {title:"Gascode | Cooking Gas Survey",description:"Share your cooking gas experience in Lagos and Abuja. Gascode household and property research survey.",icons:{icon:"/favicon.svg",shortcut:"/favicon.svg"}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>}
