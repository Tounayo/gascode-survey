import { env } from "cloudflare:workers";
export function database(){if(!env.DB)throw new Error("Response storage unavailable");return env.DB;}
