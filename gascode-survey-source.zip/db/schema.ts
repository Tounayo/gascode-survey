import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
export const responses=sqliteTable("responses",{id:text("id").primaryKey(),createdAt:text("created_at").notNull(),track:text("track").notNull(),answers:text("answers").notNull(),consentVersion:text("consent_version").notNull(),followUp:integer("follow_up").notNull().default(0)});
