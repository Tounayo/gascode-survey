CREATE TABLE `responses` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`track` text NOT NULL,
	`answers` text NOT NULL,
	`consent_version` text NOT NULL,
	`follow_up` integer DEFAULT 0 NOT NULL
);
