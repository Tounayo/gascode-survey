import { env } from "cloudflare:workers";
import {getChatGPTUser} from "@/app/chatgpt-auth";
export async function isAdmin(){const u=await getChatGPTUser();return !!u&&!!env.ADMIN_EMAIL&&u.email.toLowerCase()===env.ADMIN_EMAIL.toLowerCase();}
