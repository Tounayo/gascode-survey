export type Answers = Record<string, string | string[]>;
export type Question = {id:string; label:string; type?:"text"|"number"|"multi"|"rating"; options?:string[]; optional?:boolean; hint?:string; max?:number};
export const screening:Question[]=[
{id:"city",label:"Which city do you live or work in?",options:["Lagos","Abuja (FCT)"]},
{id:"area",label:"Area or estate",type:"text"},
{id:"role",label:"Which best describes you?",options:["Homeowner","Tenant / Renter","Estate Resident","Property Manager / Developer"]}];
export const income:Question={id:"income",label:"Q1. Estimated monthly household income",options:["Under ₦150k","₦150k – ₦350k","₦350k – ₦700k","₦700k – ₦1.5M","Above ₦1.5M","Prefer not to say"]};
export const usage:Question[]=[
{id:"fuel",label:"Q2. What is your primary cooking fuel?",options:["LPG Cylinder","Electric / Induction","Kerosene / Other"]},
{id:"sizes",label:"Cylinder size(s) used",type:"multi",options:["3–6 kg","12.5 kg","25 kg+"]},
{id:"spend",label:"Q3. Average monthly gas spend (₦)",type:"number",max:100000000,hint:"Enter 0 if you do not buy gas."},
{id:"refill",label:"Refill frequency",options:["Weekly","Bi-weekly","Monthly","Other / Less often","Not applicable"]}];
export const pains:Question[]=[
{id:"pain_running_out",label:"Running out unexpectedly mid-cooking",type:"rating"},
{id:"pain_safety",label:"Safety hazards, leak risks & cylinder storage indoors",type:"rating"},
{id:"pain_transport",label:"Physical strain & transport hassle during refills",type:"rating"},
{id:"pain_quality",label:"Vendor cheating (under-filling or bad gas quality)",type:"rating"}];
export const adoption:Question[]=[
{id:"appeal",label:"Q5. How appealing is piped smart gas to your household?",options:["1 — Unappealing","2 — Neutral","3 — Moderately appealing","4 — Very appealing"]},
{id:"connection_fee",label:"Q6. What upfront connection fee would you be willing to pay?",options:["Up to ₦25,000","Up to ₦50,000","Up to ₦100,000","Tariff markup (₦0 upfront)"]},
{id:"switch",label:"Q7. Likelihood to switch if installed in your estate today",options:["Highly unlikely","Neutral / Need pilot","Highly likely"]}];
export const profile:Question[]=[
{id:"company",label:"B1. Organization name",type:"text"},
{id:"sector",label:"Primary sector",options:["Residential Developer","Facility Management","Commercial / Hospitality"]},
{id:"operating_city",label:"B2. Operating city",options:["Lagos","Abuja (FCT)"]},
{id:"units",label:"Number of units managed or planned",type:"number",max:10000000}];
export const infrastructure:Question[]=[
{id:"setup",label:"B3. Current gas setup in your portfolio",options:["Individual cylinders per unit","Central bulk tank (unmetered)","No existing gas infrastructure"]},
{id:"concerns",label:"B4. Primary operational concerns",type:"multi",options:["Safety risks / fire hazards","Building aesthetic damage from cylinders","Tenant billing friction"]},
{id:"scope",label:"B5. Deployment scope",options:["Retrofit active properties","New pipeline developments only","Both"]}];
export const models=["Fully Outsourced (Build-Operate)","Shared Capex Model","Direct Contractor Purchase"];
export const commercial:Question[]=[
{id:"model",label:"B6. Preferred commercial infrastructure model",options:models,hint:"Choose your preferred option. The descriptions below explain each model."},
{id:"timeline",label:"B7. Expected implementation timeline",options:["Less than 6 months","6–12 months","12+ months"]},
{id:"authority",label:"Decision authority",type:"text",hint:"For example: owner, board, investment committee or estate association."}];
export const contact:Question[]=[
{id:"contact_name",label:"Name / title (optional)",type:"text",optional:true},
{id:"contact_details",label:"Email / phone (optional)",type:"text",optional:true,hint:"Only provide this if you would like Gascode to follow up."}];
export const concept="Piped Smart Gas provides continuous LPG piped directly into your household, measured by a prepaid digital meter. Pay-as-you-go via mobile app/USSD with zero refills required.";
export function isBusiness(a:Answers){return a.role==="Property Manager / Developer"}
export function stepsFor(a:Answers){return isBusiness(a)?[
{title:"Let’s start with you",short:"About you",questions:screening},
{title:"Your organization & property",short:"Property profile",questions:profile},
{title:"Your gas infrastructure",short:"Infrastructure",questions:infrastructure},
{title:"Commercial preferences",short:"Commercial models",questions:commercial},
{title:"Contact & follow-up",short:"Follow-up",questions:contact}
]:[
{title:"Let’s start with you",short:"About you",questions:[...screening,income]},
{title:"Your cooking gas today",short:"Gas usage",questions:usage.filter(q=>q.id!=="sizes"||a.fuel==="LPG Cylinder")},
{title:"Your cylinder experience",short:"Pain points",questions:pains},
{title:"A different way to use gas",short:"Smart gas",questions:adoption}
]}
export function optionsFor(q:Question){return q.type==="rating"?["1","2","3","4","5","Not applicable"]:q.options}
export function questionError(q:Question,v:unknown):string|null{
 if(q.optional&&(v===undefined||v===""))return null;
 if(q.type==="multi")return !Array.isArray(v)||v.length===0||new Set(v).size!==v.length||v.some(x=>!q.options!.includes(x))?"Choose at least one valid option.":null;
 if(typeof v!=="string"||!v.trim())return "Please answer this question.";
 if(v.length>200)return "Please keep your answer under 200 characters.";
 if(q.type==="number")return !/^\d+(\.\d{1,2})?$/.test(v)||Number(v)>(q.max??1e8)||(q.id==="units"&&!Number.isInteger(Number(v)))?"Enter a valid non-negative number.":null;
 const opts=optionsFor(q);return opts&&!opts.includes(v)?"Choose one of the listed options.":null;
}
export function cleanAnswers(a:Answers):Answers{
 const questions=stepsFor(a).flatMap(s=>s.questions);
 return Object.fromEntries(questions.filter(q=>a[q.id]!==undefined).map(q=>[q.id,typeof a[q.id]==="string"?(a[q.id] as string).trim():a[q.id]]));
}
export function validateAnswers(a:Answers){const e:Record<string,string>={};for(const q of stepsFor(a).flatMap(s=>s.questions)){const m=questionError(q,a[q.id]);if(m)e[q.id]=m}return e}

